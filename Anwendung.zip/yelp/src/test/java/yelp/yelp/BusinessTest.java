package yelp.yelp;

import static org.junit.Assert.*;

import org.junit.Test;

public class BusinessTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
