package yelp.yelp;

import org.junit.Assert;
import org.junit.Test;

public class UtilityTest {
	
	final double DELTA = 0.0001;

	@Test
	public void testDistFrom() {
		
		Assert.assertEquals(0.0, Utility.distFrom(33.5677948, -112.1611773, 33.5677948, -112.1611773), DELTA);
	}
	
	@Test
	public void testCalculateRecommendationValue() {
		
		Assert.assertEquals(4.981485, Utility.calculateRecommendationValue(5.0, 1.0, 1.0), DELTA);
		Assert.assertEquals(3.333333, Utility.calculateRecommendationValue(5.0, 1.0, 10.0), DELTA);
		Assert.assertEquals(2.5, Utility.calculateRecommendationValue(5.0, 0.5, 10.0), DELTA);
		Assert.assertEquals(1.166666, Utility.calculateRecommendationValue(1.0, 0.5, 10.0), DELTA);

	}

}
