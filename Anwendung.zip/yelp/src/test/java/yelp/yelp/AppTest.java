package yelp.yelp;

import static org.junit.Assert.*;

import org.junit.Test;

public class AppTest {

	@Test
	public void test() {
		fail("Not yet implemented");
	}

}
