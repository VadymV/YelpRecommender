package yelp.yelp;

import java.util.HashMap;
import java.util.Map;

import org.bson.Document;

import com.google.common.collect.ListMultimap;
import com.google.common.collect.MultimapBuilder;
import com.mongodb.Block;
import com.mongodb.client.FindIterable;

/**
 * This abstract class contains extra functions for {@link App} class. 
 * 
 * @author yelp.group
 *
 */
public abstract class Utility {
	
	/**
	 * Calculates distance between coordinates.
	 * 
	 * @param lat1 latitude
	 * @param lng1 longitude
	 * @param lat2 latitude
	 * @param lng2 longitude
	 * @return distance in kilometers.
	 */
	public static double distFrom(final double lat1, final double lng1, final double lat2, final double lng2) {
		
	    final double earthRadius = 6371000; //meters
	    final double dLat = Math.toRadians(lat2-lat1);
	    final double dLng = Math.toRadians(lng2-lng1);
	    final double a = Math.sin(dLat/2) * Math.sin(dLat/2) +
	               Math.cos(Math.toRadians(lat1)) * Math.cos(Math.toRadians(lat2)) *
	               Math.sin(dLng/2) * Math.sin(dLng/2);
	    final double c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1-a));
	    final double dist = (double) (earthRadius * c);

	    return dist / 1000;
	    
	    }
	
	/**
	 * Calculates a recommendation value.
	 * 
	 * @param stars stars
	 * @param probability probability
	 * @param distance distance
	 * @return a recommendation value.
	 */
	public static double calculateRecommendationValue(final double stars, final double probability, final double distance) {
		
		double recommendation = ((2 * stars * probability) / 3)
				+ ((5 - (5 * Math.pow(Math.E, (0.5 * (distance - 10))))) / 3);
		
		if (probability > 0.50) {
			
			double correction = Math.min(0.5, 5 - recommendation); 
			recommendation += correction; 
		}
		
		return recommendation;
	}

	/**
	 * Calculates recommended businesses.
	 * @param businesses
	 * @param radius
	 * @return A list of businesses.
	 */
	public static ListMultimap<Double, Business> calculateRecommendedBusinesses(final Map<String, Business> businesses, final double radius) {
		
	    //final Map<Double, Business> recommendedBusinesses = new HashMap<Double, Business>();
	    //ListMultimap<Double, Business> recommendedBusinesses = ArrayListMultimap.create();
	    ListMultimap<Double, Business> recommendedBusinesses = MultimapBuilder.treeKeys().arrayListValues().build();
		for(Map.Entry<String, Business> pair : businesses.entrySet()) {
			
			final double distance = pair.getValue().getDistance();
			
			if (distance <= radius) {
				final double stars = pair.getValue().getStars();
				final double probability = pair.getValue().getProbability();
				final double recommendation = calculateRecommendationValue(stars, probability, distance);
				recommendedBusinesses.put(recommendation, pair.getValue());
			}
			
		}
		
		return recommendedBusinesses;
	}

	/**
	 * All Businesses are converted from Document Type to Map.
	 * @param iterable Iterable collection of Documents.
	 * @param latitude Latitude.
	 * @param longitude Longitude.
	 * @param city City.
	 * @return A Map of Businesses.
	 */
	public static Map<String, Business> getSelectedBusinesses(final FindIterable<Document> iterable,
			final double latitude, final double longitude, final String city) {
		
	    final Map<String, Business> businesses = new HashMap<String, Business>();
	    
		iterable.forEach(new Block<Document>() {
		    public void apply(final Document document) {
		    	final double lat = (Double) document.get("latitude");
		    	final double lng = (Double) document.get("longitude");
		    	final String business_id = (String) document.get("business_id");
		    	final String name = (String) document.get("name");
		    	final double stars = (Double) document.get("stars");
		    	final double distance = Utility.distFrom(lat, lng, latitude, longitude);
		    	final double probability =  (Double) document.get("probability");
		    	
		    	final Business business = new Business(city, name, stars, distance, probability);
		    	
		    	businesses.put(business_id, business);
		    }
		});
		
		return businesses;
	}
}
