package yelp.yelp;

/**
 * This class holds all relevant information about a business.
 * 
 * @author yelp.group
 *
 */
public class Business {
	
	String city = "";
	String name = "";
	double stars = 0.0;
	double distance = 0.0;
	double probability = 0.0;
	

	public Business(final String city, final String name, final double stars, final double distance, final double probability) {
		this.city = city;
		this.name = name;
		this.stars = stars;
		this.distance = distance;
		this.probability = probability;
	}

	public String getCity() {
		return city;
	}

	public void setCity(final String city) {
		this.city = city;
	}

	public String getName() {
		return name;
	}

	public void setName(final String name) {
		this.name = name;
	}

	public double getStars() {
		return stars;
	}

	public void setStars(final double stars) {
		this.stars = stars;
	}

	public double getDistance() {
		return distance;
	}

	public void setDistance(final double distance) {
		this.distance = distance;
	}
	
	public double getProbability() {
		return probability;
	}

	public void setProbability(final double probability) {
		this.probability = probability;
	}
}
