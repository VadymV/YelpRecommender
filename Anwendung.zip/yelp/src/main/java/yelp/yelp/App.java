package yelp.yelp;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoDatabase;

import org.bson.Document;

import com.google.common.collect.ListMultimap;
import com.mongodb.client.FindIterable;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;



/**
 * Runs the Recommendation System.
 *
 */
public class App 
{
	final private static MongoClient mongoClient = new MongoClient();
	final private static MongoDatabase db = mongoClient.getDatabase("yelp");
	
	public static void main(String[] args) throws NumberFormatException, IOException, InterruptedException {
		
		
		boolean continue_search = true;
		while (continue_search) {
			System.out.println("Welcome");
			System.out.println("Meanwhile we have specified 30 topics, not all of them will be included.");
			System.out.println("This is caused by viewing the businesses only with the highest probability belonging to the one topic");
			System.out.println("Available cities: 412");
			System.out.println("For more results please enter one of the following cities:");
			System.out.println("                : Las Vegas, Edinburgh, Pittsburgh, Madison");
			System.out.println("                : Montréal, Phoenix, Charlotte");

			System.out.println("Enter your city, e.g. Las Vegas: ");
			BufferedReader stdin_city = new BufferedReader(new InputStreamReader(System.in));
			final String city = stdin_city.readLine();
			System.out.println("##########################");

			System.out.println("Available categories: restaurants, shopping, health");
			System.out.println("Please be advised that the most businesses are located in the category restaurants.");
			System.out.println("So do not wonder if you get an empty list in the shopping or health category.");
			System.out.println("Enter your category, e.g. restaurants: ");
			BufferedReader stdin_category = new BufferedReader(new InputStreamReader(System.in));
			final String category = stdin_category.readLine();
			System.out.println("##########################");

			if (category.contains("restaurants")) {
				System.out.println("Available topics: ");
				System.out.println("10 : Sandwiches");
				System.out.println("2 : Korean");
				System.out.println("3 : French");
				System.out.println("4 : Pizza");
				System.out.println("9 : Hot Dogs");
				System.out.println("10 : Sandwiches");
				System.out.println("13 : Indian");
				System.out.println("14 : Burgers");
				System.out.println("15 : Sushi");
				System.out.println("22 : Sea Food");
				System.out.println("24 : Vegan");
				System.out.println("25 : Italian");
				System.out.println("27 : Mexican");
				System.out.println("29 : Beer Bar");
			}
			
			if (category.contains("shopping")) {
				System.out.println("Please be advised that this category has only 312 businesses distributed over 412 cities.");
				System.out.println("Available topics: ");
				System.out.println("20 : Shoes");
				System.out.println("28 : Glasses");
			}
			
			if (category.contains("health")) {
				System.out.println("1 : Hair Treatement");
				System.out.println("2 : Pediatrician");
				System.out.println("12 : Dermatologist");
				System.out.println("5 : Dentist");
				System.out.println("8 : Workout");
				System.out.println("20 : Surgeon");
				System.out.println("24 : Chripopractor");
				System.out.println("29 : Hospitals");
				System.out.println("18 : Workout & Nutrition");
			}
			
			System.out.println("Please be advised that not all topics are here shown. There are 1-30 Topics per category.");
			System.out.println("Enter the number of the topic, e.g. 4: ");
			BufferedReader stdin_choice = new BufferedReader(new InputStreamReader(System.in));
			final String choice = stdin_choice.readLine();
			System.out.println("##########################");

			
			System.out.println("Enter your latitude, e.g. 36.271468: ");
			BufferedReader stdin_lat = new BufferedReader(new InputStreamReader(System.in));
			final double latitude = Double.parseDouble(stdin_lat.readLine());
			System.out.println("##########################");

			
			System.out.println("Enter your longitude, e.g. -115.270352: ");
			BufferedReader stdin_lng = new BufferedReader(new InputStreamReader(System.in));
			final double longitude = Double.parseDouble(stdin_lng.readLine());
			System.out.println("##########################");

			
			System.out.println("Enter your preferrable radius search in kilometres. It has to be <= 10.0, e.g. 5.0 : ");
			final BufferedReader radiusString = new BufferedReader(new InputStreamReader(System.in));
			final double radius = Double.parseDouble(radiusString.readLine());
			System.out.println("##########################");

			
			
			final FindIterable<Document> iterable = db.getCollection(category).find(new Document("city", city).
					append("topic", choice));	        
		    final Map<String, Business> businesses = Utility.getSelectedBusinesses(iterable, latitude, longitude, city);
			final ListMultimap<Double, Business> recommendedBusinesses = Utility.calculateRecommendedBusinesses(businesses, radius);

			System.out.println("Recommendation from bottom to the top");
			for(Map.Entry<Double, Business> pair : recommendedBusinesses.entries()) {
		        System.out.println(pair.getKey() + "   Name: " + pair.getValue().getName() + "   Stars: " + pair.getValue().getStars() + "   Distance: " + pair.getValue().getDistance() + "   Probability: " + pair.getValue().getProbability());
				System.out.println("------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------");

			}
			System.out.println("Continue search? yes/no: ");
			BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
			String search = input.readLine();
			
			if (search.equals("no")) {
				continue_search = false;
				System.out.println("Bye");
				System.exit(0);
			}	
		}
	}
}
